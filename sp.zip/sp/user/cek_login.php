<?php 
// mengaktifkan session php
session_start();
 
// menghubungkan dengan koneksi
require_once 'koneksi.php';
 
// menangkap data yang dikirim dari form

$email = $_POST['email'];
$password = sha1($_POST['password']);

 
// menyeleksi data admin dengan username dan password yang sesuai
$data = mysqli_query($dbc,"SELECT email, pass FROM user WHERE email= '$email' AND pass='$password'");
 
// menghitung jumlah data yang ditemukan
$cek = mysqli_num_rows($data);
 
if($cek > 0){
	$_SESSION['email'] = $email;
	$_SESSION['status'] = "login";
	header("location:user_guade.php");
}else{
	header("location:index.php?pesan=gagal");
}
?>