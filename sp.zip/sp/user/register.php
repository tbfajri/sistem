<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>SB Admin - Start Bootstrap Template</title>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
</head>

<body class="bg-dark">
  <div class="container">
    <div class="card card-register mx-auto mt-5">
      <div class="card-header">Register an Account</div>
      <div class="card-body">
        <?php 
$judul_hal = 'Registrasi';

// memeriksa apakah form sudah disubmit
if (isset($_POST['disubmit'])){
  require_once ('koneksi.php');
  $arrayError = array(); // inisial array error


  // memeriksa nama depan
  if(empty($_POST['nama_depan'])) {
    $arrayError[] = 'Anda lupa memasukan nama depan .';
  } else {
    $fn = mysqli_real_escape_string($dbc, trim($_POST['nama_depan']));
  }

  // memeriksa nama belakang 
  if(empty($_POST['nama_belakang'])){
    $arrayError[] = 'Anda Lupa memasukan nama bekang.';
  } else {
    $ln = mysqli_real_escape_string($dbc, trim($_POST['nama_belakang']));
  }

  // memeriksa alamat email
  if(empty($_POST['email'])){
    $arrayError[] = 'Anda lupa memasukan Alamat Email .';

  } else {
    $e = mysqli_real_escape_string($dbc, trim($_POST['email']));
  }

  // memeriksa password dan mencocokan password konfirmasi

  if (!empty($_POST['pass1'])) {
    if ($_POST['pass1'] != $_POST['pass2']) {
      $arrayError[] = 'password anda tidak cocok dengan password konfirmasi';
    } else {
      $p = mysqli_real_escape_string($dbc,trim($_POST['pass1']));
    }
  } else {
    $arrayError[] = 'Anda lupa memasukan password. ';
  }

  if(empty($arrayError)) {
    // jika semua benar oke registrasi ke database
    require_once ('koneksi.php');

    // melakukan query
    $q = "INSERT INTO user (nama_depan, nama_belakang, email, pass, tanggal_registrasi)
    VALUES ('$fn','$ln','$e',SHA1('$p'),NOW() )";
    $r = @mysqli_query ($dbc, $q);
    if ($r) {
      // if semua ok run
      // menampilkan pesan
      echo '<h1>Terimaksih !</h1>
      <p> anda sekarang telah terdaftar ! </p>';
      echo '<a href><input type="buton" value="LOGIN"></a>';

    } else {
      // jika ada masalah
      // pesan error
      echo '<h1>Error Sistem </h1>
      <p class="eror"> anda belum terdaftar!.</p>';

      // pesan debugging
      echo '<p>'.mysqli_error($dbc).'<br /><br />Query: '.$q.'</p>';
    } mysqli_close($dbc);
    exit();
  } else { // melaporkan array error
    echo '<h1> ERROR!!</h1>
    <p class="eror">Berikut adalah error yang terjadi : <br />';
    foreach ($arrayError as $psn) { // menampilkan tiap error 
      echo "- $psn<br />\n";
    }
    echo '</p><p>Silakan coba lagi.</p><p><br /></p>';
  }
  mysqli_close($dbc);
}
?>
        <form action="register.php" method="POST" action="register.php">
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="exampleInputName">First name</label>
                <input class="form-control" id="exampleInputName" type="text" aria-describedby="nameHelp" name="nama_depan" placeholder="Enter first name" value="<?php if (isset($_POST['nama_depan'])) echo $_POST['nama_depan']; ?>" />
              </div>
              <div class="col-md-6">
                <label for="exampleInputLastName">Last name</label>
                <input class="form-control" id="exampleInputLastName" type="text" aria-describedby="nameHelp" placeholder="Enter last name" name="nama_belakang" value="<?php if (isset($_POST['nama_belakang'])) echo $_POST['nama_belakang']; ?>" />
              </div>
            </div>
          </div>
          <div class="form-group">
            <label for="exampleInputEmail1">Email address</label>
            <input class="form-control" id="exampleInputEmail1" type="email" aria-describedby="emailHelp" placeholder="Enter email" name="email" value="<?php if (isset($_POST['email'])) echo $_POST['email']; ?>" />
          </div>
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="exampleInputPassword1">Password</label>
                <input class="form-control" id="exampleInputPassword1" type="password" name="pass1" placeholder="Password">
              </div>
              <div class="col-md-6">
                <label for="exampleConfirmPassword">Confirm password</label>
                <input class="form-control" id="exampleConfirmPassword" type="password" placeholder="Confirm password" name="pass2">
              </div>
            </div>
          </div>
          <input type="submit" name="submit" value="Registrasi" /> </p>
        <input type="hidden" name="disubmit" value="True" />
        </form>
        <div class="text-center">
          <a class="d-block small mt-3" href="Login.php">Login Page</a>
          
        </div>
      </div>
    </div>
  </div>
  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
</body>

</html>
