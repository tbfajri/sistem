<?php 
	// file koneksi akses ke database

	// menetapkan konstanta informsai akses database

Define('DB_USER', 'root');
Define('DB_PASSWORD', '');
Define('DB_HOST', 'localhost');
Define('DB_NAME', 'sistem_pakar');

// koneksi ke database

$dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) OR die ('Tidak dapat terhubung ke mysql '.mysqli_connect_error());
?>