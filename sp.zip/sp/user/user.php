<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Sistem Pakar Diagnosa Penyakit THT</title>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
   <?php include 'menu.html';?>
 
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#">Input Gejala</a>
        </li>
        <li class="breadcrumb-item active">My Dashboard</li>
      </ol>
    
      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i> Data Table Example</div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              
               <form method="POST" action="input.php">
    <tr>
      <th><center>No</center></th>
      <th>Gejala yang anda rasakan</th>
      <th>Centang</th>
      <th>Nilai Evidance</th>
    </tr>
    <?php

    // koneksi 
  
    require_once "koneksi.php";
    if(isset($_POST['hapus'])) {
        $hapus_hidung = "DELETE FROM bayes_hidung2 ";
    $rh = @mysqli_query($dbc, $hapus_hidung);
    }
    if(isset($_POST['hapus'])) {
        $hapus_telinga = "DELETE FROM bayes_telinga2 ";
    $rt = @mysqli_query($dbc, $hapus_telinga);
    }
    if(isset($_POST['hapus'])) {
        $hapus_tenggorokan = "DELETE FROM bayes_tenggorokan2 ";
    $rr = @mysqli_query($dbc, $hapus_tenggorokan);
    }

    $q = "SELECT gejala.gejala_tenggorokan, rumus_gejala.nilai FROM gejala INNER JOIN rumus_gejala WHERE gejala.id_gejala = rumus_gejala.id ";
    $data = @mysqli_query($dbc, $q);
    $no = 1;
    while($d = mysqli_fetch_array($data)){
    ?>




    <tr>
      <td><center><?php echo $no++; ?></center></td>
      <td><?php echo "Apakah anda merasakan " . $d['gejala_tenggorokan'] . " ?" ; ?></td>
      <td><center>
        <input type="checkbox" name="nama_gejala[]" value="<?php echo $d['nilai']; ?>">
        </center>
      </td>
      <td><?php echo $d['nilai']; ?></td>   
    </tr>
    <?php }
    ?>

  </table>
<input class="btn btn-primary" type="submit" value="Simpan" name="input">
  </form>

              </tbody>
            </table>
          </div>
        </div>
        <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
      </div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <footer class="sticky-footer">
      <div class="container">
        <div class="text-center">
          <small>Copyright © Your Website 2018</small>
        </div>
      </div>
    </footer>
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a>
    <!-- Logout Modal-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="login.php">Logout</a>
          </div>
        </div>
      </div>
    </div>
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <script src="js/sb-admin-datatables.min.js"></script>
    <script src="js/sb-admin-charts.min.js"></script>
  </div>
</body>

</html>
