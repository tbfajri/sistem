<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Sistem Pakar Diagnosa Penyakit THT</title>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
</head>
<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <div class="container">
    <div class="card card-login mx-auto mt-5">
      <div class="card-header">Input Evidance</div>
      <div class="card-body">
      	<?php 
      	include 'menu.html';

// memeriksa apakah form sudah disubmit
if (isset($_POST['disubmit'])){
	require_once ('koneksi.php');
	$arrayError = array(); // inisial array error


	// memeriksa nama gejala telinga
	if(empty($_POST['gejala_telinga'])) {
		$arrayError[] = 'Anda lupa memasukan Evidance Telinga.';
	} else {
		$fn = mysqli_real_escape_string($dbc, trim($_POST['gejala_telinga']));
	}

	// memeriksa nama gejala hidung
	if(empty($_POST['gejala_hidung'])){
		$arrayError[] = 'Anda Lupa memasukan Evidance Hidung.';
	} else {
		$ln = mysqli_real_escape_string($dbc, trim($_POST['gejala_hidung']));
	}

	// memeriksa alamat gejala tenggorokan
	if(empty($_POST['gejala_tenggorokan'])){
		$arrayError[] = 'Anda lupa memasukan Evidance Tenggorokan.';

	} else {
		$e = mysqli_real_escape_string($dbc, trim($_POST['gejala_tenggorokan']));
	}


	if(empty($arrayError)) {
		// jika semua benar oke registrasi ke database
		require_once ('koneksi.php');

		// melakukan query
		$q = "INSERT INTO gejala (gejala_telinga, gejala_hidung, gejala_tenggorokan)
		VALUES ('$fn','$ln','$e')";
		$r = @mysqli_query ($dbc, $q);
		if ($r) {
			// if semua ok run
			// menampilkan pesan
			echo '<h1>Terimaksih !</h1>
			<p> Input Evidance Berhasil ! </p>';
			echo '<a href = "tabel_diagnosa.php"><input type="button" class="btn btn-primary" value="Lihat Gejala"></a>';
			echo '<align = "left"> <a href = "input_evidance.php"><input type="button" class="btn btn-primary" value="Tambah Gejala"></a>';

		} else {
			// jika ada masalah
			// pesan error
			echo '<h1>Error Sistem </h1>
			<p class="eror"> Gagal Menginput Evidance.</p>';

			// pesan debugging
			echo '<p>'.mysqli_error($dbc).'<br /><br />Query: '.$q.'</p>';
		} mysqli_close($dbc);
		exit();
	} else { // melaporkan array error
		echo '<h1> ERROR!!</h1>
		<p class="eror">Berikut adalah error yang terjadi : <br />';
		foreach ($arrayError as $psn) { // menampilkan tiap error 
			echo "- $psn<br />\n";
		}
		echo '</p><p>Silakan coba lagi.</p><p><br /></p>';
	}
	mysqli_close($dbc);
}
?>
<form action="input_evidance.php" method="POST">
	<div class="form-group">
		 <label for="exampleInputEmail1"> Gejala Telinga</label>
            <input class="form-control" id="exampleInputEmail1" type="text" aria-describedby="emailHelp" name="gejala_telinga" value="<?php if (isset($_POST['gejala_telinga'])) echo $_POST['gejala_telinga']; ?>" />

          </div>
          <div class="form-group">
		 <label for="exampleInputEmail1"> Gejala Hidung</label>
            <input class="form-control" id="exampleInputEmail1" type="text" aria-describedby="emailHelp" name="gejala_hidung" value="<?php if (isset($_POST['gejala_hidung'])) echo $_POST['gejala_hidung']; ?>" />
          </div>

          <div class="form-group">
		 <label for="exampleInputEmail1"> Gejala Tenggorokan</label>
            <input class="form-control" id="exampleInputEmail1" type="text" aria-describedby="emailHelp"  name="gejala_tenggorokan" value="<?php if (isset($_POST['gejala_tenggorokan'])) echo $_POST['gejala_tenggorokan']; ?>" />
          </div>
				<p><input type="submit" name="submit" class="btn btn-primary" value="Simpan" /> </p>
				<input type="hidden" name="disubmit" value="True" />

</form>

        </div>
        <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
      </div>
    </div>

    
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <footer class="sticky-footer">
      <div class="container">
        <div class="text-center">
          <small>Copyright © Universitas Serang Raya 2018</small>
        </div>
      </div>
    </footer>
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a>
    <!-- Logout Modal-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="index.php">Logout</a>
          </div>
        </div>
      </div>
    </div>
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <script src="js/sb-admin-datatables.min.js"></script>
  </div>
</body>

</html>