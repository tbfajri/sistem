<!DOCTYPE html>
<html>
<head>
	<title>Sistem Pakar Diagnosa Penyakit THT </title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
	<h1>Nilai Tunggal ke tunggal</h1>
	<form method="POST" action="bayes_t_g.php">
		<?php 
	
	$x = $_POST['nama_gejala'];

	// var_dump($x);
	$b = count($x);
	$p = 0;
	for ($i=0; $i < $b; $i++) { 
		$p += $x[$i];
	}

	$p = 0.423 / ($b * 0.423);
	
?>
	<input type="hidden" name="total" value="<?php echo $p; ?>">
	<input type="hidden" name="proses" value="<?php echo 0.423 . " / " . $b . " x " . 0.423; ?>">

	<table border="1" name="bayes_tunggal">
		<tr>
			<th>
			P(E|H) x P(H) / P(E)
			</th>
			<th>P(H|E</th>
		</tr>
		<tr>	
				
			<td>
				<?php
				require_once 'koneksi.php';
				$q = "SELECT rumus_gejala.nilai, rumus_penyakit.hasil FROM rumus_gejala INNER JOIN rumus_penyakit";
				$data = @mysqli_query($dbc, $q);
				$d = mysqli_fetch_array($data);
				if (isset($_POST['nama_gejala'])){
					# code...
					$gejala = $_POST['nama_gejala'];
					$jumlah_dipilih = count($gejala);
 					$num = 1;
					for($x=0;$x<$jumlah_dipilih;$x++){ 

					$nilai = ($gejala[$x] * $d['hasil'] ) / $gejala[$x];
					
			echo $gejala[$x] . " x " . $d['hasil'] . " / " . $gejala[$x];
			echo "<br />";

					
					if (isset($_POST['input'])){

					 if ($x == 1){
						// $kali = $gejala[$x] * $d['hasil'] * $gejala[$x];
					$kali = $gejala[$x] * $d['hasil'] * $gejala[$x];
					$ganda = $kali * $jumlah_dipilih;
					$final = $kali / $ganda;


					}


			
			
				} 
			} 
 			}else {
				echo 'Anda sehat';
			
 				}
?></td>	
			<td><?php if (isset($_POST['nama_gejala'])) {
			$gejala = $_POST['nama_gejala'];
					$jumlah_dipilih = count($gejala);
 
					for($x=0;$x<$jumlah_dipilih;$x++){ 
					
					$nilai = ($gejala[$x] * $d['hasil']) / $gejala[$x];
			echo number_format($nilai,3);

			echo "<br />";
			
			
				} } else {
					echo '0';
				}

				?></td>
		</tr>
	</table>
		<input type="hidden" name="nilai_tunggal" value="<?php echo number_format($nilai,3); ?>">
		<input type="hidden" name="kali" value="<?php echo $final ?>">
		<input type="hidden" name="kali_2" value="<?php echo $kali ." / ". $ganda; ?>">
		<input type="submit" name="simpan" value="Next">
	</form>
</body>
</html>
