-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 24 Apr 2018 pada 09.07
-- Versi server: 10.1.30-MariaDB
-- Versi PHP: 5.6.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sistem_pakar`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `nama_depan` varchar(100) NOT NULL,
  `nama_belakang` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `tanggal_registrasi` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id`, `nama_depan`, `nama_belakang`, `email`, `pass`, `tanggal_registrasi`) VALUES
(1, 'Tb Fajri', 'Mulyana', 'tbfajri@ymail.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '2018-03-21'),
(2, 'tbfajri', 'mulyana', 'tbfajri7@gmail.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '2018-04-09'),
(3, 'tbfajri', 'yayan', 'tbfajri@ymail.com', '8cb2237d0679ca88db6464eac60da96345513964', '2018-04-22'),
(4, 'yayan', 'ganteng', 'tbfajri@yayan.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '2018-04-22');

-- --------------------------------------------------------

--
-- Struktur dari tabel `bayes_hidung`
--

CREATE TABLE `bayes_hidung` (
  `id` int(11) NOT NULL,
  `nilai_tunggal` double NOT NULL,
  `nilai_t_g` double NOT NULL,
  `nilai_g_g` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `bayes_hidung`
--

INSERT INTO `bayes_hidung` (`id`, `nilai_tunggal`, `nilai_t_g`, `nilai_g_g`) VALUES
(1, 0.423, 0.25, 0.25),
(2, 0.423, 0.333, 0.333),
(3, 0.423, 0.167, 0.167),
(4, 0.423, 0.5, 0.5),
(5, 0.423, 0.333, 0.333),
(6, 0.423, 0.333, 0.333),
(7, 0.423, 0.2, 0.2),
(8, 0.423, 0.5, 0.5),
(9, 0.423, 0.2, 0.2),
(10, 0.423, 0.25, 0.25),
(11, 0.423, 0.333, 0.333),
(12, 0.423, 0.5, 0.5),
(13, 0.423, 0.25, 0.25),
(14, 0.423, 0.25, 0.25),
(15, 0.423, 0.25, 0.25),
(16, 0.423, 0.25, 0.25),
(17, 0.423, 0.25, 0.25),
(18, 0.423, 0.25, 0.25),
(19, 0.423, 0.25, 0.25),
(20, 0.423, 0.143, 0.143),
(21, 0.423, 0.333, 0.333),
(22, 0.423, 0.5, 0.5),
(23, 0.423, 0.25, 0.25),
(24, 0.423, 0.2, 0.2),
(25, 0.423, 0.2, 0.2),
(26, 0.423, 0.25, 0.25),
(27, 0.423, 0.333, 0.333),
(28, 0.423, 0.5, 0.5),
(29, 0.423, 0.25, 0.25);

-- --------------------------------------------------------

--
-- Struktur dari tabel `bayes_hidung2`
--

CREATE TABLE `bayes_hidung2` (
  `id` int(11) NOT NULL,
  `nilai_tunggal` double NOT NULL,
  `nilai_t_g` double NOT NULL,
  `nilai_g_g` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `bayes_hidung2`
--

INSERT INTO `bayes_hidung2` (`id`, `nilai_tunggal`, `nilai_t_g`, `nilai_g_g`) VALUES
(11, 0.423, 0.5, 0.5),
(12, 0.423, 0.25, 0.25);

-- --------------------------------------------------------

--
-- Struktur dari tabel `bayes_telinga`
--

CREATE TABLE `bayes_telinga` (
  `id` int(11) NOT NULL,
  `nilai_tunggal` double NOT NULL,
  `nilai_t_g` double NOT NULL,
  `nilai_g_g` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `bayes_telinga`
--

INSERT INTO `bayes_telinga` (`id`, `nilai_tunggal`, `nilai_t_g`, `nilai_g_g`) VALUES
(1, 0.423, 0.5, 0.5),
(2, 0.423, 0.333, 0.333),
(3, 0.423, 0.2, 0.2),
(4, 0.423, 0.5, 0.5),
(5, 0.423, 0.333, 0.333),
(6, 0.423, 0.25, 0.25),
(7, 0.423, 0.333, 0.333),
(8, 0.423, 0.333, 0.333),
(9, 0.423, 0.333, 0.333),
(10, 0.423, 0.5, 0.5),
(11, 0.423, 0.25, 0.25),
(12, 0.423, 0.333, 0.333),
(13, 0.423, 0.333, 0.333),
(14, 0.423, 0.333, 0.333),
(15, 0.423, 0.333, 0.333),
(16, 0.423, 0.333, 0.333),
(17, 0.423, 0.333, 0.333),
(18, 0.423, 0.333, 0.333),
(19, 0.423, 0.333, 0.333),
(20, 0.423, 0.333, 0.333),
(21, 0.423, 0.5, 0.5),
(22, 0.423, 0.333, 0.333),
(23, 0.423, 0.333, 0.333),
(24, 0.423, 0.333, 0.333),
(25, 0.423, 0.5, 0.5),
(26, 0.423, 0.1, 0.1),
(27, 0.423, 0.5, 0.5),
(28, 0.423, 0.25, 0.25),
(29, 0.423, 0.333, 0.333);

-- --------------------------------------------------------

--
-- Struktur dari tabel `bayes_telinga2`
--

CREATE TABLE `bayes_telinga2` (
  `id` int(11) NOT NULL,
  `nilai_tunggal` double NOT NULL,
  `nilai_t_g` double NOT NULL,
  `nilai_g_g` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `bayes_telinga2`
--

INSERT INTO `bayes_telinga2` (`id`, `nilai_tunggal`, `nilai_t_g`, `nilai_g_g`) VALUES
(11, 0.423, 0.25, 0.25),
(12, 0.423, 0.333, 0.333);

-- --------------------------------------------------------

--
-- Struktur dari tabel `bayes_tenggorokan`
--

CREATE TABLE `bayes_tenggorokan` (
  `id` int(11) NOT NULL,
  `nilai_tunggal` double NOT NULL,
  `nilai_t_g` double NOT NULL,
  `nilai_g_g` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `bayes_tenggorokan`
--

INSERT INTO `bayes_tenggorokan` (`id`, `nilai_tunggal`, `nilai_t_g`, `nilai_g_g`) VALUES
(1, 0.423, 0.5, 0.5),
(2, 0.423, 0.5, 0.5),
(3, 0.423, 0.5, 0.5),
(4, 0.423, 0.5, 0.5),
(5, 0.423, 0.5, 0.5),
(6, 0.423, 0.5, 0.5),
(7, 0.423, 0.5, 0.5),
(8, 0.423, 0.5, 0.5),
(9, 0.423, 0.5, 0.5),
(10, 0.423, 0.333, 0.333),
(11, 0.423, 0.5, 0.5),
(12, 0.423, 0.5, 0.5),
(13, 0.423, 0.333, 0.333),
(14, 0.423, 0.5, 0.5),
(15, 0.423, 0.2, 0.2),
(16, 0.423, 0.25, 0.25),
(17, 0.423, 0.5, 0.5);

-- --------------------------------------------------------

--
-- Struktur dari tabel `bayes_tenggorokan2`
--

CREATE TABLE `bayes_tenggorokan2` (
  `id` int(11) NOT NULL,
  `nilai_tunggal` double NOT NULL,
  `nilai_t_g` double NOT NULL,
  `nilai_g_g` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `bayes_tenggorokan2`
--

INSERT INTO `bayes_tenggorokan2` (`id`, `nilai_tunggal`, `nilai_t_g`, `nilai_g_g`) VALUES
(12, 0.423, 0.25, 0.25),
(13, 0.423, 0.5, 0.5);

-- --------------------------------------------------------

--
-- Struktur dari tabel `gejala`
--

CREATE TABLE `gejala` (
  `id_gejala` int(11) NOT NULL,
  `gejala_telinga` varchar(100) NOT NULL,
  `gejala_hidung` varchar(100) NOT NULL,
  `gejala_tenggorokan` varchar(100) NOT NULL,
  `n` int(11) NOT NULL,
  `Nn` int(11) NOT NULL,
  `nilai` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `gejala`
--

INSERT INTO `gejala` (`id_gejala`, `gejala_telinga`, `gejala_hidung`, `gejala_tenggorokan`, `n`, `Nn`, `nilai`) VALUES
(1, 'lecet atau goresan pada lubang telinga', 'Nyeri pada Deviasi Septum (pembatas lubang kiri dan kanan)', 'Radang pada Tenggorokan', 0, 0, 0),
(2, 'Nyeri Telinga', 'Hidung Tersumbat', 'Bercak Merah di Tenggorokan', 0, 0, 0),
(3, 'Tuli', 'Mimisan', 'Amandel', 0, 0, 0),
(4, 'Telinga Berdengung', 'Keluar Ingusan', 'Tenggorokan Kering', 0, 0, 0),
(5, 'Telinga Terasa Penuh', 'Beraroma Tajam', 'Nyeri Tenggorokan', 0, 0, 0),
(6, 'Sakit Kepala', 'Bau Nafas', 'Sakit Saat Menelan', 0, 0, 0),
(7, 'Telinga Membengkak', 'Sakit Kepala', 'Batuk-batuk', 0, 0, 0),
(8, 'Keluar Cairan', 'Sakit Bagian Dahi', 'Gatal di tenggorokan', 0, 0, 0),
(9, 'Serangan Pertigo', 'Gangguan Penciuman', 'Pilek dan Ingusan', 0, 0, 0),
(10, 'Peradangan telinga dalam', 'Pilek dan Ingusan', 'Sakit saat menelan', 0, 0, 0),
(11, 'Perforasi Sentral', 'Pembengkakan pada dinding organ caring', 'Demam', 0, 0, 0),
(12, 'Perforasi Marginal', 'Bangkok pada Sinus', 'Sesak Napas', 0, 0, 0),
(13, 'Kolesteatoma', 'Infeksi Pernapasan Aras', 'Mual', 0, 0, 0),
(14, 'Gatel-gatel', 'Mampet', 'Kering', 0, 0, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `gejala_hidung`
--

CREATE TABLE `gejala_hidung` (
  `id` int(11) NOT NULL,
  `nama_gejala` varchar(100) NOT NULL,
  `n` int(11) NOT NULL,
  `Nn` int(11) NOT NULL,
  `nilai` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `gejala_telinga`
--

CREATE TABLE `gejala_telinga` (
  `id` int(11) NOT NULL,
  `nama_gejala` varchar(100) NOT NULL,
  `n` int(11) NOT NULL,
  `Nn` int(11) NOT NULL,
  `nilai` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `gejala_tenggorokan`
--

CREATE TABLE `gejala_tenggorokan` (
  `id` int(11) NOT NULL,
  `nama_gejala` varchar(100) NOT NULL,
  `n` int(11) NOT NULL,
  `Nn` int(11) NOT NULL,
  `nilai` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `gejala_user`
--

CREATE TABLE `gejala_user` (
  `id` int(11) NOT NULL,
  `nama_gejala` varchar(100) NOT NULL,
  `nilai_gejala` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `nilai_evidance`
--

CREATE TABLE `nilai_evidance` (
  `id` int(10) NOT NULL,
  `nama_gejala` varchar(100) NOT NULL,
  `nilai` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `nilai_evidance`
--

INSERT INTO `nilai_evidance` (`id`, `nama_gejala`, `nilai`) VALUES
(1, 'Tuli', 5),
(2, 'Nyeri Telinga', 3.6),
(3, 'Nyeri Telinga', 3.6),
(4, 'Nyeri Telinga', 3.6),
(5, 'Nyeri Telinga', 3.6),
(6, 'Amandel', 1.2),
(7, 'Amandel', 1.2),
(8, 'lecet atau goresan pada lubang telinga', 0.2),
(9, 'lecet atau goresan pada lubang telinga', 0.2),
(10, 'lecet atau goresan pada lubang telinga', 0.2),
(11, 'Tuli', 0.2),
(12, 'Tuli', 0.2),
(13, 'lecet atau goresan pada lubang telinga', 0.8),
(14, 'lecet atau goresan pada lubang telinga', 8);

-- --------------------------------------------------------

--
-- Struktur dari tabel `rumus_gejala`
--

CREATE TABLE `rumus_gejala` (
  `id` int(11) NOT NULL,
  `n` double NOT NULL,
  `Nn` double NOT NULL,
  `nilai` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `rumus_gejala`
--

INSERT INTO `rumus_gejala` (`id`, `n`, `Nn`, `nilai`) VALUES
(1, 1, 26, 0.038),
(2, 1, 26, 0.038),
(3, 1, 26, 0.038),
(4, 1, 26, 0.038),
(5, 1, 26, 0.038),
(6, 1, 26, 0.038),
(7, 1, 26, 0.038),
(8, 2, 26, 0.077),
(9, 1, 26, 0.038),
(10, 1, 26, 0.038),
(11, 1, 26, 0.038),
(12, 1, 26, 0.038),
(13, 1, 26, 0.038),
(14, 1, 26, 0.038),
(15, 1, 26, 0.038),
(16, 2, 26, 0.077),
(17, 1, 26, 0.038),
(18, 1, 26, 0.038),
(19, 1, 26, 0.038),
(20, 1, 26, 0.038),
(21, 1, 26, 0.038),
(22, 1, 26, 0.038),
(23, 1, 26, 0.038),
(24, 1, 26, 0.038),
(25, 1, 26, 0.038),
(27, 1, 26, 0.038),
(28, 1, 23, 0.043),
(29, 2, 26, 0.077);

-- --------------------------------------------------------

--
-- Struktur dari tabel `rumus_penyakit`
--

CREATE TABLE `rumus_penyakit` (
  `id` int(11) NOT NULL,
  `n` double NOT NULL,
  `Nn` double NOT NULL,
  `hasil` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `rumus_penyakit`
--

INSERT INTO `rumus_penyakit` (`id`, `n`, `Nn`, `hasil`) VALUES
(1, 11, 26, 0.423),
(2, 8, 26, 0.308),
(3, 7, 26, 0.269),
(4, 0, 0, 0),
(5, 2, 3, 0.667);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `nama_depan` varchar(100) NOT NULL,
  `nama_belakang` varchar(30) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `tanggal_registrasi` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `nama_depan`, `nama_belakang`, `email`, `pass`, `tanggal_registrasi`) VALUES
(1, 'tbfajri', '', 'tbfajri', '123', '0000-00-00'),
(2, 'tes', 'tes', 'tes@tes.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '2018-04-22');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `bayes_hidung`
--
ALTER TABLE `bayes_hidung`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `bayes_hidung2`
--
ALTER TABLE `bayes_hidung2`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `bayes_telinga`
--
ALTER TABLE `bayes_telinga`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `bayes_telinga2`
--
ALTER TABLE `bayes_telinga2`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `bayes_tenggorokan`
--
ALTER TABLE `bayes_tenggorokan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `bayes_tenggorokan2`
--
ALTER TABLE `bayes_tenggorokan2`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `gejala`
--
ALTER TABLE `gejala`
  ADD PRIMARY KEY (`id_gejala`);

--
-- Indeks untuk tabel `gejala_hidung`
--
ALTER TABLE `gejala_hidung`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `gejala_telinga`
--
ALTER TABLE `gejala_telinga`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `gejala_tenggorokan`
--
ALTER TABLE `gejala_tenggorokan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `gejala_user`
--
ALTER TABLE `gejala_user`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `nilai_evidance`
--
ALTER TABLE `nilai_evidance`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `rumus_gejala`
--
ALTER TABLE `rumus_gejala`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `rumus_penyakit`
--
ALTER TABLE `rumus_penyakit`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `bayes_hidung`
--
ALTER TABLE `bayes_hidung`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT untuk tabel `bayes_hidung2`
--
ALTER TABLE `bayes_hidung2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `bayes_telinga`
--
ALTER TABLE `bayes_telinga`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT untuk tabel `bayes_telinga2`
--
ALTER TABLE `bayes_telinga2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `bayes_tenggorokan`
--
ALTER TABLE `bayes_tenggorokan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT untuk tabel `bayes_tenggorokan2`
--
ALTER TABLE `bayes_tenggorokan2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT untuk tabel `gejala`
--
ALTER TABLE `gejala`
  MODIFY `id_gejala` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT untuk tabel `gejala_hidung`
--
ALTER TABLE `gejala_hidung`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `gejala_telinga`
--
ALTER TABLE `gejala_telinga`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `gejala_tenggorokan`
--
ALTER TABLE `gejala_tenggorokan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `gejala_user`
--
ALTER TABLE `gejala_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `nilai_evidance`
--
ALTER TABLE `nilai_evidance`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT untuk tabel `rumus_gejala`
--
ALTER TABLE `rumus_gejala`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT untuk tabel `rumus_penyakit`
--
ALTER TABLE `rumus_penyakit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
